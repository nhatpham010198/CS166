Prob of a node not in the LLC is q
Prob of a node in the LLC is 1-q


```python
import math
def f(k,q):
    return(math.e**(k*(q-1)))
```


```python
x = [x/100 for x in range(1,10,1)]
y = [f(0.5,i) for i in x]
```


```python
import matplotlib.pyplot as plt
plt.plot(x,y)
plt.show
```




    <function matplotlib.pyplot.show(*args, **kw)>




![png](output_3_1.png)



```python
def calculate_q(k):
    import numpy as np
    from scipy.optimize import root
    return root(lambda q: q - np.exp(k * (q - 1)), 0).x[0]
k = list(range(1,10,1))
y = [calculate_q(i) for i in k]
plt.plot(k,y)
plt.show
plt.xlabel('k')
plt.ylabel('Size of LLC')
```




    Text(0, 0.5, 'Size of LLC')




![png](output_4_1.png)



```python

```
